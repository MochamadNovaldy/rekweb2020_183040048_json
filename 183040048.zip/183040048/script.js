let mahasiswa = {
    nama : "Mochamad Novaldy",
    nrp : "183040048",
    email : "novaldy.183040048@unpas.ac.id"
}

console.log(JSON.stringify(mahasiswa));